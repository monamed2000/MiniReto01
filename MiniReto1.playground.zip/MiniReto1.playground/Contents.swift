//: Playground - noun: a place where people can play

import UIKit


for var i = 0; i <= 100; i++ {
    if i % 2 == 0 {
        print("\(i) par")
    }else if i % 2 > 0 {
        print("\(i) impar")
    }
    if (i >= 30 && i <= 40) {
        print("viva Swift") //para no imprimir 2 veces el número
    }
    if (i > 0 && i % 5 == 0) {
        print(" Bingo") //para no imprimir 2 veces el número
    }

}
